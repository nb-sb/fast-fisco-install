This folder contains sample Fabric networks for testing with caliper. Each network requires an enviroment variable to be set for `FABRIC_VERSION` so that the correct level network is created.

Please inspect nested folder README files for more information.